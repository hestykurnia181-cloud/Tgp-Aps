import React, { useState } from 'react';
import {
  AlertCircle,
  Banknote,
  CheckCircle2,
  Minus,
  Package,
  Plus,
  QrCode,
  Receipt,
  Search,
  ShoppingCart,
  Store,
  Tag,
  Percent,
  Trash2,
  X,
  Edit3,
} from 'lucide-react';
import { PosReceiptModal } from '../components/PosReceiptModal';
import { useTgp } from '../context/TgpContext';
import { BusinessModule, ItemEntity, PaymentMethod, SaleOrderEntity } from '../types';

function formatRupiah(amount: number): string {
  return 'Rp ' + Math.round(amount).toLocaleString('id-ID');
}

export const PosScreen: React.FC = () => {
  const {
    activeBusiness,
    activeItems,
    activeOutlets,
    activeOutletStocks,
    cart,
    cartTotal,
    addToCart,
    removeFromCart,
    updateCartItemQuantity,
    clearCart,
    checkout,
    currentSession,
  } = useTgp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [paymentMethod, setPaymentMethod] = useState<'TUNAI' | 'QRIS' | 'TRANSFER'>('TUNAI');
  const [nominalReceived, setNominalReceived] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [completedSale, setCompletedSale] = useState<SaleOrderEntity | null>(null);

  // Manual Quantity Modal State (e.g. for bulk items like tebu, custom orders)
  const [quantityModalItem, setQuantityModalItem] = useState<ItemEntity | null>(null);
  const [manualQuantityInput, setManualQuantityInput] = useState<string>('1');

  // Discount State
  const [isDiscountOpen, setIsDiscountOpen] = useState<boolean>(false);
  const [discountType, setDiscountType] = useState<'NONE' | 'PERCENT' | 'NOMINAL'>('NONE');
  const [discountValueInput, setDiscountValueInput] = useState<string>('');
  const [discountNote, setDiscountNote] = useState<string>('');

  // If user is assigned to a specific stan
  const userAssignedOutletId = currentSession?.user.outletId;
  const [selectedOutletId, setSelectedOutletId] = useState<string>(
    userAssignedOutletId || (activeOutlets[0] ? activeOutlets[0].outletId : '')
  );

  const hasStanModule = activeBusiness?.activeModules.includes(BusinessModule.STAN_OUTLET);

  // Available items for sell (PRODUCT, MENU_DISH, SERVICE). RAW_MATERIAL is not directly sold on POS.
  const sellableItems = activeItems.filter(
    (i) => i.type !== 'RAW_MATERIAL'
  );

  const categories = Array.from(new Set(sellableItems.map((i) => i.category)));

  const filteredItems = sellableItems.filter((i) => {
    const matchSearch =
      i.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat = selectedCategory === 'ALL' || i.category === selectedCategory;
    return matchSearch && matchCat;
  });

  const getItemEffectiveStock = (item: ItemEntity): number => {
    if (item.type === 'SERVICE') return 9999;
    if (hasStanModule && selectedOutletId) {
      const stanStock = activeOutletStocks.find(
        (s) => s.outletId === selectedOutletId && s.itemId === item.itemId
      );
      return stanStock ? stanStock.stockQuantity : 0;
    }
    return item.stockQuantity;
  };

  // Calculations
  const cartSubtotal = cartTotal; // Gross subtotal of all selected items
  const numericDiscountVal = parseFloat(discountValueInput) || 0;
  let discountAmount = 0;
  if (discountType === 'PERCENT') {
    const clampedPercent = Math.min(100, Math.max(0, numericDiscountVal));
    discountAmount = Math.round((cartSubtotal * clampedPercent) / 100);
  } else if (discountType === 'NOMINAL') {
    discountAmount = Math.min(cartSubtotal, Math.max(0, numericDiscountVal));
  }
  const finalCartTotal = Math.max(0, cartSubtotal - discountAmount);

  // Open manual quantity dialog when cashier clicks an item card
  const handleOpenQuantityModal = (item: ItemEntity) => {
    const stock = getItemEffectiveStock(item);
    if (item.type !== 'SERVICE' && stock <= 0) return;
    const existingInCart = cart.find((c) => c.item.itemId === item.itemId);
    setQuantityModalItem(item);
    setManualQuantityInput(existingInCart ? existingInCart.quantity.toString() : '1');
  };

  const handleConfirmManualQuantity = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!quantityModalItem) return;

    const parsedQty = parseInt(manualQuantityInput, 10);
    const validQty = isNaN(parsedQty) || parsedQty <= 0 ? 1 : parsedQty;
    const maxStock = getItemEffectiveStock(quantityModalItem);

    if (quantityModalItem.type !== 'SERVICE' && validQty > maxStock) {
      alert(`Stok '${quantityModalItem.name}' tidak mencukupi! Tersedia hanya ${maxStock} ${quantityModalItem.unit}.`);
      return;
    }

    updateCartItemQuantity(quantityModalItem.itemId, validQty);
    setQuantityModalItem(null);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const paid = paymentMethod === 'TUNAI' ? parseFloat(nominalReceived) || finalCartTotal : finalCartTotal;
    const pm = paymentMethod === 'TUNAI' ? PaymentMethod.CASH : (paymentMethod as PaymentMethod);

    const sale = checkout(
      pm,
      hasStanModule && selectedOutletId ? selectedOutletId : undefined,
      paid,
      {
        type: discountType,
        value: numericDiscountVal,
        amount: discountAmount,
        note: discountNote.trim() || undefined,
        customerName: customerName.trim() || undefined,
      }
    );

    if (sale) {
      setIsCheckoutOpen(false);
      setCustomerName('');
      setNominalReceived('');
      setDiscountType('NONE');
      setDiscountValueInput('');
      setDiscountNote('');
      setIsDiscountOpen(false);
      setCompletedSale(sale);
    }
  };

  const numericPaid = parseFloat(nominalReceived) || 0;
  const changeDue = Math.max(0, numericPaid - finalCartTotal);

  return (
    <div className="pb-20 space-y-4">
      {/* Header Bar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 leading-tight">
              Kasir POS ({activeBusiness?.name})
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Pilih item, atur jumlah manual (seperti tebu), tambah diskon, dan cetak struk
            </p>
          </div>
        </div>

        {/* Stan / Outlet Switcher if Multi-Stan is active */}
        {hasStanModule && activeOutlets.length > 0 && (
          <div className="flex items-center gap-2">
            <Store className="w-4 h-4 text-amber-600 shrink-0" />
            <select
              value={selectedOutletId}
              onChange={(e) => setSelectedOutletId(e.target.value)}
              disabled={!!userAssignedOutletId}
              className="px-3 py-1.5 rounded-xl border border-amber-300 bg-amber-50/60 text-xs font-bold text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              {activeOutlets.map((o) => (
                <option key={o.outletId} value={o.outletId}>
                  Stand: {o.name} ({o.code})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left / Middle: Catalog Items List (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-3">
          {/* Search & Category Filter */}
          <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs space-y-2.5">
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Cari nama produk / SKU (tekan item untuk atur jumlah jual)..."
                data-testid="input_pos_search"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            </div>

            {/* Category Badges */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setSelectedCategory('ALL')}
                className={`px-3 py-1 rounded-xl font-bold whitespace-nowrap transition ${
                  selectedCategory === 'ALL'
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Semua ({sellableItems.length})
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-xl font-bold whitespace-nowrap transition ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {filteredItems.length === 0 ? (
              <div className="col-span-full py-12 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200">
                Tidak ada produk yang cocok dengan pencarian.
              </div>
            ) : (
              filteredItems.map((item) => {
                const stock = getItemEffectiveStock(item);
                const isOutOfStock = item.type !== 'SERVICE' && stock <= 0;
                const inCart = cart.find((c) => c.item.itemId === item.itemId);

                return (
                  <div
                    key={item.itemId}
                    onClick={() => {
                      if (!isOutOfStock) {
                        handleOpenQuantityModal(item);
                      }
                    }}
                    data-testid={`pos_item_${item.name.replace(/\s+/g, '_')}`}
                    className={`p-3 rounded-2xl border transition text-left flex flex-col justify-between cursor-pointer group relative ${
                      isOutOfStock
                        ? 'opacity-50 border-slate-200 bg-slate-50 cursor-not-allowed'
                        : inCart
                        ? 'border-blue-500 bg-blue-50/40 ring-2 ring-blue-500/20 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-blue-400 hover:shadow-xs'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">
                          {item.category}
                        </span>
                        {inCart && (
                          <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-extrabold flex items-center justify-center shrink-0">
                            {inCart.quantity}
                          </span>
                        )}
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-2 mt-1 leading-snug">
                        {item.name}
                      </h4>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-end justify-between">
                      <div>
                        <span className="text-xs font-extrabold text-blue-600 block">
                          {formatRupiah(item.sellingPrice)}
                        </span>
                        <span
                          className={`text-[10px] font-semibold ${
                            stock <= 3 && item.type !== 'SERVICE'
                              ? 'text-rose-600'
                              : 'text-slate-400'
                          }`}
                        >
                          {item.type === 'SERVICE' ? 'Layanan' : `Stok: ${stock} ${item.unit}`}
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg opacity-90 group-hover:bg-blue-600 group-hover:text-white transition">
                        Atur Qty
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Active Cart, Discounts & Checkout (5 cols on lg) */}
        <div className="lg:col-span-5">
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between h-full min-h-[480px]">
            <div className="space-y-3">
              {/* Cart Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-blue-600" />
                  <h3 className="text-sm font-extrabold text-slate-900">Keranjang Transaksi</h3>
                </div>
                {cart.length > 0 && (
                  <button
                    onClick={clearCart}
                    className="text-[11px] font-bold text-rose-600 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Kosongkan</span>
                  </button>
                )}
              </div>

              {/* Cart Item Rows */}
              <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto pr-1">
                {cart.length === 0 ? (
                  <div className="py-12 text-center text-xs text-slate-400 space-y-1">
                    <ShoppingCart className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="font-semibold">Keranjang Masih Kosong</p>
                    <p className="text-[11px]">Tekan produk di katalog untuk menentukan jumlah yang ingin dijual.</p>
                  </div>
                ) : (
                  cart.map(({ item, quantity }) => {
                    const itemTotal = item.sellingPrice * quantity;
                    const stock = getItemEffectiveStock(item);

                    return (
                      <div key={item.itemId} className="py-3 flex items-center justify-between gap-2 text-xs">
                        <div className="min-w-0 flex-1">
                          <p className="font-bold text-slate-900 truncate leading-tight">{item.name}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {formatRupiah(item.sellingPrice)} &times; {quantity} {item.unit || 'pcs'}
                          </p>
                          <p className="text-xs font-extrabold text-blue-600 mt-0.5">
                            Total: {formatRupiah(itemTotal)}
                          </p>
                        </div>

                        {/* Quantity Controller with Direct Manual Input */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => updateCartItemQuantity(item.itemId, quantity - 1)}
                            className="w-6 h-6 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition"
                            title="Kurangi 1"
                          >
                            <Minus className="w-3 h-3" />
                          </button>

                          {/* Direct Manual Number Input in Cart Row */}
                          <input
                            type="number"
                            min="1"
                            max={item.type === 'SERVICE' ? 9999 : stock}
                            value={quantity}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10);
                              if (!isNaN(val) && val > 0) {
                                updateCartItemQuantity(item.itemId, val);
                              }
                            }}
                            className="w-11 py-0.5 px-1 text-center font-black text-xs border border-slate-200 rounded-md focus:ring-1 focus:ring-blue-500 bg-white"
                            title="Ketik jumlah langsung"
                          />

                          <button
                            onClick={() => {
                              if (item.type === 'SERVICE' || quantity < stock) {
                                updateCartItemQuantity(item.itemId, quantity + 1);
                              }
                            }}
                            className="w-6 h-6 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition"
                            title="Tambah 1"
                          >
                            <Plus className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => handleOpenQuantityModal(item)}
                            className="p-1 text-slate-400 hover:text-blue-600 rounded transition ml-0.5"
                            title="Ubah jumlah secara manual"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => removeFromCart(item.itemId)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                            title="Hapus dari keranjang"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Discount Section (Foldable / Configurable) */}
              {cart.length > 0 && (
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/90 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                      <Tag className="w-3.5 h-3.5 text-amber-600" />
                      <span>Diskon Penjualan</span>
                    </div>

                    {discountAmount > 0 ? (
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                          -{formatRupiah(discountAmount)}
                        </span>
                        <button
                          onClick={() => {
                            setDiscountType('NONE');
                            setDiscountValueInput('');
                            setDiscountNote('');
                          }}
                          className="text-[10px] text-slate-400 hover:text-rose-600 font-bold"
                          title="Hapus diskon"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setIsDiscountOpen(!isDiscountOpen)}
                        className="text-[11px] font-bold text-blue-600 hover:underline"
                      >
                        {isDiscountOpen ? 'Tutup Diskon' : '+ Tambah Diskon'}
                      </button>
                    )}
                  </div>

                  {/* Expandable Discount Controls */}
                  {(isDiscountOpen || discountAmount > 0) && (
                    <div className="pt-2 border-t border-slate-200 space-y-2 text-xs">
                      {/* Mode Toggle: Percent vs Nominal */}
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setDiscountType('PERCENT');
                            if (!discountValueInput) setDiscountValueInput('10');
                          }}
                          className={`py-1.5 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1 transition ${
                            discountType === 'PERCENT'
                              ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <Percent className="w-3 h-3" />
                          <span>Persen (%)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setDiscountType('NOMINAL');
                            if (!discountValueInput) setDiscountValueInput('5000');
                          }}
                          className={`py-1.5 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1 transition ${
                            discountType === 'NOMINAL'
                              ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <Banknote className="w-3 h-3" />
                          <span>Nominal (Rp)</span>
                        </button>
                      </div>

                      {/* Inputs */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-bold text-slate-500 block mb-0.5">
                            {discountType === 'PERCENT' ? 'Nilai Persen (%)' : 'Jumlah Potongan (Rp)'}
                          </label>
                          <input
                            type="number"
                            min="0"
                            max={discountType === 'PERCENT' ? 100 : cartSubtotal}
                            value={discountValueInput}
                            onChange={(e) => {
                              setDiscountValueInput(e.target.value);
                              if (discountType === 'NONE') setDiscountType('NOMINAL');
                            }}
                            placeholder={discountType === 'PERCENT' ? 'Contoh: 10' : 'Contoh: 5000'}
                            className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-500 block mb-0.5">
                            Keterangan / Alasan
                          </label>
                          <input
                            type="text"
                            value={discountNote}
                            onChange={(e) => setDiscountNote(e.target.value)}
                            placeholder="Promo / Member / dll"
                            className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                          />
                        </div>
                      </div>

                      {/* Quick Preset Buttons */}
                      <div className="flex flex-wrap gap-1 pt-1">
                        {discountType === 'PERCENT' ? (
                          [5, 10, 15, 20, 50].map((pct) => (
                            <button
                              key={pct}
                              type="button"
                              onClick={() => {
                                setDiscountType('PERCENT');
                                setDiscountValueInput(pct.toString());
                              }}
                              className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 text-[10px] font-bold hover:bg-slate-100"
                            >
                              {pct}%
                            </button>
                          ))
                        ) : (
                          [2000, 5000, 10000, 20000, 50000].map((amt) => {
                            if (amt > cartSubtotal && amt !== 2000) return null;
                            return (
                              <button
                                key={amt}
                                type="button"
                                onClick={() => {
                                  setDiscountType('NOMINAL');
                                  setDiscountValueInput(amt.toString());
                                }}
                                className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 text-[10px] font-bold hover:bg-slate-100"
                              >
                                {formatRupiah(amt)}
                              </button>
                            );
                          })
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setDiscountType('NONE');
                            setDiscountValueInput('');
                            setDiscountNote('');
                            setIsDiscountOpen(false);
                          }}
                          className="px-2 py-0.5 rounded-md bg-slate-200 text-slate-600 text-[10px] font-bold hover:bg-slate-300"
                        >
                          Hapus
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Cart Summary & Checkout Trigger */}
            <div className="pt-3 border-t border-slate-200/90 space-y-2.5 mt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-semibold">Total Barang:</span>
                <span className="font-bold text-slate-800">
                  {cart.reduce((a, c) => a + c.quantity, 0)} item ({cart.length} jenis)
                </span>
              </div>

              {/* Rincian Harga Total Penjualan */}
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>Subtotal Item:</span>
                <span className="font-bold text-slate-800">{formatRupiah(cartSubtotal)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex items-center justify-between text-xs text-emerald-600 font-bold">
                  <span>Diskon Penjualan{discountNote ? ` (${discountNote})` : ''}:</span>
                  <span>- {formatRupiah(discountAmount)}</span>
                </div>
              )}

              <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                <div>
                  <span className="text-xs font-bold text-slate-700 block">Total Akhir Penjualan:</span>
                  <span className="text-[10px] text-slate-400 font-medium">Sudah dipotong diskon</span>
                </div>
                <span
                  data-testid="cart_total_amount"
                  className="text-xl font-black text-blue-600 tracking-tight"
                >
                  {formatRupiah(finalCartTotal)}
                </span>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(true)}
                disabled={cart.length === 0}
                data-testid="btn_open_checkout"
                className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition active:scale-[0.99]"
              >
                <Banknote className="w-4 h-4" />
                <span>Bayar Sekarang ({formatRupiah(finalCartTotal)})</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Quantity Modal for Selected Item (e.g. Tebu) */}
      {quantityModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Masukkan Jumlah Jual</h3>
                <p className="text-xs text-slate-500 truncate max-w-[220px]">
                  {quantityModalItem.name}
                </p>
              </div>
              <button
                onClick={() => setQuantityModalItem(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmManualQuantity} className="mt-4 space-y-4 text-xs">
              {/* Item Info Card */}
              <div className="p-3 bg-blue-50/60 rounded-2xl border border-blue-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-wider font-bold text-blue-600 block">
                    Harga Satuan
                  </span>
                  <span className="text-sm font-black text-slate-900">
                    {formatRupiah(quantityModalItem.sellingPrice)} / {quantityModalItem.unit}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block">
                    Stok Tersedia
                  </span>
                  <span className="text-xs font-bold text-slate-700">
                    {quantityModalItem.type === 'SERVICE'
                      ? 'Layanan (Tak Terbatas)'
                      : `${getItemEffectiveStock(quantityModalItem)} ${quantityModalItem.unit}`}
                  </span>
                </div>
              </div>

              {/* Manual Quantity Input Field */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Jumlah {quantityModalItem.name} yang Dijual ({quantityModalItem.unit}):
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const current = parseInt(manualQuantityInput, 10) || 1;
                      if (current > 1) setManualQuantityInput((current - 1).toString());
                    }}
                    className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black flex items-center justify-center transition"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <input
                    type="number"
                    min="1"
                    max={quantityModalItem.type === 'SERVICE' ? 9999 : getItemEffectiveStock(quantityModalItem)}
                    value={manualQuantityInput}
                    onChange={(e) => setManualQuantityInput(e.target.value)}
                    autoFocus
                    className="flex-1 px-3 py-2.5 border border-slate-300 rounded-xl text-center font-black text-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const current = parseInt(manualQuantityInput, 10) || 0;
                      const maxStock = getItemEffectiveStock(quantityModalItem);
                      if (quantityModalItem.type === 'SERVICE' || current < maxStock) {
                        setManualQuantityInput((current + 1).toString());
                      }
                    }}
                    className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black flex items-center justify-center transition"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Quick Presets (+1, +2, +5, +10, +20, +50) */}
              <div>
                <span className="text-[10px] font-bold text-slate-400 block mb-1">Pilihan Cepat:</span>
                <div className="grid grid-cols-6 gap-1">
                  {[1, 2, 5, 10, 20, 50].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setManualQuantityInput(preset.toString())}
                      className="py-1.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-600 font-extrabold text-[11px] text-slate-700 transition"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Total Calculation for this Item */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600">Total Harga Item Ini:</span>
                <span className="text-sm font-black text-blue-600">
                  {formatRupiah(
                    quantityModalItem.sellingPrice * (parseInt(manualQuantityInput, 10) || 0)
                  )}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setQuantityModalItem(null)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
                >
                  Simpan ke Keranjang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Pembayaran Kasir</h3>
                <p className="text-xs text-slate-500">Pilih metode & catat uang pembayaran</p>
              </div>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="mt-4 space-y-4 text-xs">
              {/* Payment Methods */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">Metode Pembayaran</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'TUNAI', label: 'Tunai (Cash)', icon: Banknote },
                    { id: 'QRIS', label: 'QRIS', icon: QrCode },
                    { id: 'TRANSFER', label: 'Transfer Bank', icon: Receipt },
                  ].map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setPaymentMethod(id as any)}
                      className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 transition ${
                        paymentMethod === id
                          ? 'border-blue-600 bg-blue-50/80 text-blue-700 font-extrabold ring-1 ring-blue-500'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-[11px]">{label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Summary of Total & Discount */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between items-center text-slate-500">
                  <span>Subtotal Item ({cart.reduce((a, c) => a + c.quantity, 0)} item):</span>
                  <span className="font-bold text-slate-700">{formatRupiah(cartSubtotal)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between items-center text-emerald-600 font-bold">
                    <span>Diskon Penjualan{discountNote ? ` (${discountNote})` : ''}:</span>
                    <span>- {formatRupiah(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-1.5 border-t border-slate-200">
                  <span className="font-extrabold text-slate-900">Total Tagihan Bersih:</span>
                  <span className="text-base font-black text-blue-600">{formatRupiah(finalCartTotal)}</span>
                </div>
              </div>

              {/* Customer Name */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Pembeli (Opsional)</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Contoh: Meja 4 / Pak Budi"
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
                />
              </div>

              {/* Cash Input & Change Due Calculation */}
              {paymentMethod === 'TUNAI' && (
                <div className="space-y-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Uang Diterima dari Pembeli</label>
                    <input
                      type="number"
                      value={nominalReceived}
                      onChange={(e) => setNominalReceived(e.target.value)}
                      placeholder={finalCartTotal.toString()}
                      autoFocus
                      data-testid="input_nominal_paid"
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 font-extrabold text-sm text-slate-900 bg-white"
                    />
                  </div>

                  {/* Quick Preset Cash Buttons based on finalCartTotal */}
                  <div className="flex flex-wrap gap-1.5">
                    {[finalCartTotal, 20000, 50000, 100000, 200000].map((amt) => {
                      if (amt < finalCartTotal && amt !== finalCartTotal) return null;
                      return (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setNominalReceived(amt.toString())}
                          className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-[10px] font-bold hover:bg-slate-100"
                        >
                          {formatRupiah(amt)}
                        </button>
                      );
                    })}
                  </div>

                  {/* Change Preview */}
                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                    <span className="font-bold text-slate-600">Uang Kembalian:</span>
                    <span
                      data-testid="text_change_preview"
                      className={`text-sm font-black ${
                        numericPaid >= finalCartTotal ? 'text-emerald-600' : 'text-slate-400'
                      }`}
                    >
                      {formatRupiah(changeDue)}
                    </span>
                  </div>
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  data-testid="btn_confirm_checkout"
                  disabled={paymentMethod === 'TUNAI' && numericPaid > 0 && numericPaid < finalCartTotal}
                  className="px-5 py-2.5 font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-xl shadow-xs"
                >
                  Selesaikan & Cetak Struk
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Receipt Printable Modal */}
      <PosReceiptModal
        isOpen={!!completedSale}
        onClose={() => setCompletedSale(null)}
        sale={completedSale}
      />
    </div>
  );
};
